﻿Partial Class manageCategoryDataSet
End Class

Namespace manageCategoryDataSetTableAdapters

    Partial Public Class Table1TableAdapter
    End Class
End Namespace
