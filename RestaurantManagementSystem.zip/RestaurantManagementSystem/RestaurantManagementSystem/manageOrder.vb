﻿Imports System.Data.OleDb
Public Class manageOrder
    Dim pro As String
    Dim connstring As String
    Dim command As String
    Dim myconnection As OleDbConnection = New OleDbConnection

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim a, b, c As Integer
        a = Val(Label14.Text)
        b = Val(TextBox9.Text)
        c = a + b
        Label14.Text = c

        Table3DataGridView.CurrentRow.Cells(0).Value = ComboBox2.Text
        Table3DataGridView.CurrentRow.Cells(1).Value = ComboBox3.Text
        Table3DataGridView.CurrentRow.Cells(2).Value = ComboBox4.Text
        Table3DataGridView.CurrentRow.Cells(3).Value = TextBox8.Text
        Table3DataGridView.CurrentRow.Cells(4).Value = TextBox9.Text

        pro = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\hello\Documents\viewBill.accdb"
        connstring = pro
        myconnection.ConnectionString = connstring
        myconnection.Open()
        command = "insert into Table4 ([Name],[E-mail],[Contact Number],[Date],[Payment Method],[Total]) values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & ComboBox1.Text & "','" & TextBox9.Text & "')"
        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)
        cmd.Parameters.Add(New OleDbParameter("Name", CType(TextBox1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("E-mail", CType(TextBox2.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Contact Number", CType(TextBox3.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Date", CType(DateTimePicker1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Payment Methody", CType(ComboBox1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Total", CType(TextBox9.Text, String)))
        MsgBox("record save")

        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        viewBill.Table4BindingSource.AddNew()
        Table3BindingSource.AddNew()
        dashBoard.Label4.Text = viewBill.Table4DataGridView.RowCount
    End Sub

    Private Sub Table3BindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.Table3BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.ManageOrderDataSet)
    End Sub

    Private Sub manageOrder_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Table2TableAdapter1.Fill(Me.Manage_productDataSet1.Table2)
        Me.Table1TableAdapter.Fill(Me.CategoryDataSet.Table1)
        Me.Table3TableAdapter.Fill(Me.ManageOrderDataSet.Table3)
        ComboBox2.Text = ""
    End Sub

    Private Sub Table3DataGridView_CellFormatting(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles Table3DataGridView.CellFormatting
        Table3DataGridView.Rows(e.RowIndex).HeaderCell.Value = CStr(e.RowIndex + 1)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MsgBox("Data Save Successfully")
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        PrintDocument1.Print()

        viewBill.Table4DataGridView.CurrentRow.Cells(0).Value = TextBox1.Text
        viewBill.Table4DataGridView.CurrentRow.Cells(1).Value = TextBox2.Text
        viewBill.Table4DataGridView.CurrentRow.Cells(2).Value = TextBox3.Text
        viewBill.Table4DataGridView.CurrentRow.Cells(3).Value = DateTimePicker1.Text
        viewBill.Table4DataGridView.CurrentRow.Cells(4).Value = ComboBox1.Text
        viewBill.Table4DataGridView.CurrentRow.Cells(5).Value = Label14.Text
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.Table3DataGridView.Width, Me.Table3DataGridView.Height)
        Table3DataGridView.DrawToBitmap(bm, New Rectangle(0, 0, Me.Table3DataGridView.Width, Me.Table3DataGridView.Height))
        e.Graphics.DrawImage(bm, 0, 0)
    End Sub

    Private Sub Button4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Table3BindingSource.RemoveCurrent()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        MsgBox("Data Save Successfully")
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If Not Char.IsLetter(e.KeyChar) And Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) And Not e.KeyChar = Chr(Keys.Space) Then
            e.Handled = True
            MessageBox.Show("This Field Will Aceept Latter Only")
        End If
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        If TextBox3.Text.Length >= 10 Then
            If e.KeyChar <> ControlChars.Back Then
                e.Handled = True
                MessageBox.Show("Phone No. Should be More Then 10 Numbers")
            End If
        End If
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) And Not e.KeyChar = Chr(Keys.Space) Then
            e.Handled = True
            MessageBox.Show("This Field Will Aceept Number Only")
        End If
    End Sub

    Private Sub ComboBox1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox1.KeyPress
        If Not Char.IsLetter(e.KeyChar) And Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) And Not e.KeyChar = Chr(Keys.Space) Then
            e.Handled = True
            MessageBox.Show("This Field Will Aceept Latter Only")
        End If
    End Sub

    Private Sub TextBox7_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) And Not e.KeyChar = Chr(Keys.Space) Then
            e.Handled = True
            MessageBox.Show("This Field Will Aceept Number Only")
        End If
    End Sub

    Private Sub TextBox8_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox8.KeyPress
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) And Not e.KeyChar = Chr(Keys.Space) Then
            e.Handled = True
            MessageBox.Show("This Field Will Aceept Number Only")
        End If
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        Me.Table21TableAdapter.Fill1(Me.Manage_productDataSet1.Table21, ComboBox2.Text)
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        Me.Table22TableAdapter.Fill2(Me.Manage_productDataSet1.Table22, ComboBox3.Text)
    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged
        Dim a, b, c As Integer
        a = Val(ComboBox4.Text)
        b = Val(TextBox8.Text)
        c = a * b
        TextBox9.Text = c
    End Sub
End Class