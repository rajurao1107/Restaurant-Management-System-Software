﻿Partial Class manage_productDataSet
    Partial Class Table21DataTable

        

    End Class

End Class
