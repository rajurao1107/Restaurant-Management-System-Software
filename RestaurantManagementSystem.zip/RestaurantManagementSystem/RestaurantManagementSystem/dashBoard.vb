﻿Public Class dashBoard
    Sub switchPanel(ByVal panel As Form)
        mainPage.Panel3.Controls.Clear()
        panel.TopLevel = False
        mainPage.Panel3.Controls.Add(panel)
        panel.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        switchPanel(manageCategory)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        switchPanel(manageProduct)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        switchPanel(viewBill)
    End Sub
End Class