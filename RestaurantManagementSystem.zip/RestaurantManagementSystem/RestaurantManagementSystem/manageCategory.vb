﻿Public Class manageCategory
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        mcForm.Show()
        Table1BindingSource.AddNew()
        manageProduct.Table2BindingSource.AddNew()
        dashBoard.Label2.Text = Table1DataGridView.RowCount
        dashBoard.Label3.Text = manageProduct.Table2DataGridView.RowCount
    End Sub

    Private Sub Table1BindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.Table1BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CategoryDataSet)
    End Sub

    Private Sub manageCategory_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CategoryDataSet.Table1' table. You can move, or remove it, as needed.
        Me.Table1TableAdapter.Fill(Me.CategoryDataSet.Table1)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Table1BindingSource.Filter = "Category LIKE '" & TextBox1.Text & "%'"
    End Sub

    Private Sub Table1DataGridView_CellFormatting(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles Table1DataGridView.CellFormatting
        Table1DataGridView.Rows(e.RowIndex).HeaderCell.Value = CStr(e.RowIndex + 1)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Table1BindingSource.RemoveCurrent()
    End Sub
End Class