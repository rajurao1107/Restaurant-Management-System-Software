﻿Public Class viewBill
    Private Sub viewBill_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ViewBillDataSet.Table4' table. You can move, or remove it, as needed.
        Me.Table4TableAdapter.Fill(Me.ViewBillDataSet.Table4)
    End Sub

    Private Sub Table4BindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.Table4BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.ViewBillDataSet)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Table4BindingSource.Filter = "Name LIKE '" & TextBox1.Text & "%'"
        dashBoard.Label4.Text = Table4DataGridView.RowCount - 1
    End Sub

    Private Sub Table4DataGridView_CellFormatting(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles Table4DataGridView.CellFormatting
        Table4DataGridView.Rows(e.RowIndex).HeaderCell.Value = CStr(e.RowIndex + 1)
    End Sub
End Class